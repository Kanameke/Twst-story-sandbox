const SIM=document.body.hasAttribute("data-sim");
const $=s=>document.querySelector(s);
const AS=window.TWST_ASSETS||{backgrounds:[],sprites:[],characters:[]};
const SLOTS=[["L","Left","sL",22],["C","Center","sC",50],["R","Right","sR",78]];
const lib={bg:[...AS.backgrounds],sp:[...AS.sprites]}; // uploads get appended
const blank=()=>({name:"",text:"",bg:lib.bg[0]?.src||"",active:"L",s:{L:{src:"",flip:false,x:0},C:{src:"",flip:false,x:0},R:{src:"",flip:false,x:0}}});
let P={title:"Epel and the Missing Apple Pie",size:165,y:8,lines:[]},sel=0;
try{const s=localStorage.getItem("twst-story-v4");if(s)P=JSON.parse(s)}catch(e){}
if(!P.lines||!P.lines.length){const SP="public/sprites/",BG="public/backgrounds/room_placeholder.jpg";
 P.lines=[
 {name:"",text:"Pomefiore Dorm, late at night. Epel's door swings open with a bang.",bg:BG,active:"N",s:{L:{src:"",flip:false,x:0},C:{src:"",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"Who touched my apple pie?!",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"angry.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Rook (outside)",text:"Mon cher, calm yourself. No one has entered your room.",bg:BG,active:"L",s:{L:{src:"",flip:false,x:0},C:{src:SP+"angry.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"Then why is the plate empty, and why is there a cake fork on my bed?!",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"angry.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Rook (outside)",text:"...Perhaps the culprit was simply very hungry.",bg:BG,active:"L",s:{L:{src:"",flip:false,x:0},C:{src:SP+"angry.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"Hungry?! That pie took me three hours!",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"shrug.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Rook (outside)",text:"Then bake another, and I shall be the first to taste it. Politely, this time.",bg:BG,active:"L",s:{L:{src:"",flip:false,x:0},C:{src:SP+"shrug.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"Fine. But this time I'm locking the door.",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"fist_neutral.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Rook (outside)",text:"Locks are no match for a hunter, mon cher.",bg:BG,active:"L",s:{L:{src:"",flip:false,x:0},C:{src:SP+"fist_neutral.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"...Then I'll just put a trap in the pie.",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"hands_together_smile.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Rook (outside)",text:"How delightfully wicked!",bg:BG,active:"L",s:{L:{src:"",flip:false,x:0},C:{src:SP+"hands_together_smile.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"Epel",text:"Watch me. One perfect, booby-trapped apple pie, coming right up.",bg:BG,active:"C",s:{L:{src:"",flip:false,x:0},C:{src:SP+"fist_smile.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 {name:"",text:"And so began the Great Apple Pie Stakeout of Pomefiore... (To be continued)",bg:BG,active:"N",s:{L:{src:"",flip:false,x:0},C:{src:SP+"fist_smile.png",flip:false,x:0},R:{src:"",flip:false,x:0}}},
 ];P.title="Epel and the Missing Apple Pie";}
if(SIM&&window.TWST_STORY)P=window.TWST_STORY;
const save=()=>{try{localStorage.setItem("twst-story-v4",JSON.stringify(P))}catch(e){}};
const cur=()=>P.lines[sel];

// make sure every used image is available in the pickers
function adopt(){P.lines.forEach(l=>{if(l.bg&&!lib.bg.some(a=>a.src===l.bg))lib.bg.push({label:"(custom) "+l.bg.slice(0,20),src:l.bg});
 for(const k in l.s){const s=l.s[k].src;if(s&&!lib.sp.some(a=>a.src===s))lib.sp.push({label:"(custom sprite)",src:s});}});}

// shrink text only if it would overflow the box
function fitText(t){const e=$("#txt");e.textContent=t;let s=2.1;e.style.fontSize=s+"cqw";e.style.lineHeight=(s*1.24)+"cqw";
  while(e.scrollHeight>e.clientHeight+1&&s>1.3){s-=.08;e.style.fontSize=s+"cqw";e.style.lineHeight=(s*1.24)+"cqw"}}
// ---------- stage render ----------
function renderStage(l,typed){
  $("#bg").src=l.bg||"";$("#bg").style.display=l.bg?"":"none";
  SLOTS.forEach(([k,,id,base])=>{
    const d=$("#"+id),s=l.s[k],im=d.firstElementChild;
    d.style.setProperty("--sh",P.size+"%");d.style.setProperty("--sy",P.y+"%");
    d.style.left=(base+(+s.x||0))+"%";
    if(s.src){im.src=s.src;d.style.display=""}else d.style.display="none";
    d.classList.toggle("flip",!!s.flip);
    d.classList.toggle("dim",l.active!=="N"&&l.active!==k);
  });
  {const nm=$("#name");nm.textContent=l.name||"";let ns=2.2;nm.style.fontSize=ns+"cqw";while(nm.scrollWidth>nm.clientWidth+1&&ns>1.2){ns-=.1;nm.style.fontSize=ns+"cqw"}}
  if(typed===undefined)fitText(l.text);
}

// ---------- editor ----------
function fillSelect(sel_,arr,none){sel_.innerHTML=(none?'<option value="">— none —</option>':'')+arr.map(a=>`<option value="${a.src.replace(/"/g,'&quot;')}">${a.label}</option>`).join("")}
function buildSlots(){
  $("#slots").innerHTML=SLOTS.map(([k,n])=>`<div class="slot"><b>${n}</b>
   <div class="row"><select data-sp="${k}"></select><button class="sm" data-up="${k}">Upload…</button></div>
   <div class="row"><label style="margin:0 8px 0 0"><input type="checkbox" data-fl="${k}" style="width:auto"> Flip</label>
   <div style="flex:3"><input type="range" data-x="${k}" min="-30" max="30" value="0" title="Horizontal offset"></div></div></div>`).join("");
  SLOTS.forEach(([k])=>{
    const s=document.querySelector(`[data-sp=${k}]`);fillSelect(s,lib.sp,true);
    s.onchange=()=>{cur().s[k].src=s.value;upd()};
    document.querySelector(`[data-fl=${k}]`).onchange=e=>{cur().s[k].flip=e.target.checked;upd()};
    document.querySelector(`[data-x=${k}]`).oninput=e=>{cur().s[k].x=+e.target.value;upd()};
  });
}
function loadForm(){
  const l=cur();
  $("#fName").value=l.name;$("#fText").value=l.text;$("#fActive").value=l.active;
  fillSelect($("#fBg"),lib.bg,true);$("#fBg").value=l.bg;
  SLOTS.forEach(([k])=>{
    const s=document.querySelector(`[data-sp=${k}]`);fillSelect(s,lib.sp,true);s.value=l.s[k].src;
    document.querySelector(`[data-fl=${k}]`).checked=!!l.s[k].flip;
    document.querySelector(`[data-x=${k}]`).value=l.s[k].x||0;
  });
  $("#gSize").value=P.size;$("#gY").value=P.y;$("#title").value=P.title;
}
function renderList(){
  $("#list").innerHTML=P.lines.map((l,i)=>`<div class="item ${i===sel?"sel":""}" data-i="${i}"><span class="n">${i+1}</span><span class="who">${l.name||"—"}</span><span class="t">${(l.text||"").replace(/</g,"&lt;")}</span></div>`).join("");
  document.querySelectorAll(".item").forEach(e=>e.onclick=()=>{sel=+e.dataset.i;refresh()});
}
function upd(){renderStage(cur());renderList();save()}
function refresh(){loadForm();renderStage(cur());renderList();save()}

$("#fName").oninput=e=>{cur().name=e.target.value;upd()};
$("#fText").oninput=e=>{cur().text=e.target.value;upd()};
$("#fActive").onchange=e=>{cur().active=e.target.value;upd()};
$("#fBg").onchange=e=>{cur().bg=e.target.value;upd()};
$("#gSize").oninput=e=>{P.size=+e.target.value;upd()};
$("#gY").oninput=e=>{P.y=+e.target.value;upd()};
$("#title").oninput=e=>{P.title=e.target.value;save()};
$("#add").onclick=()=>{const n=JSON.parse(JSON.stringify(cur()));n.text="";P.lines.splice(sel+1,0,n);sel++;refresh();$("#fText").focus()};
$("#dup").onclick=()=>{P.lines.splice(sel+1,0,JSON.parse(JSON.stringify(cur())));sel++;refresh()};
$("#del").onclick=()=>{if(P.lines.length>1){P.lines.splice(sel,1);sel=Math.max(0,sel-1)}else P.lines[0]=blank();refresh()};
$("#up").onclick=()=>{if(sel>0){[P.lines[sel-1],P.lines[sel]]=[P.lines[sel],P.lines[sel-1]];sel--;refresh()}};
$("#dn").onclick=()=>{if(sel<P.lines.length-1){[P.lines[sel+1],P.lines[sel]]=[P.lines[sel],P.lines[sel+1]];sel++;refresh()}};
$("#chars").innerHTML=(AS.characters||[]).map(c=>`<option value="${c}">`).join("");

// uploads → dataURL so they survive export/import
let upTarget=null;
document.addEventListener("click",e=>{const t=e.target.closest("[data-up]");if(t){upTarget=t.dataset.up;$("#upF").value="";$("#upF").click()}});
$("#upF").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{
  const src=r.result,label="(upload) "+f.name;
  if(upTarget==="bg"){lib.bg.push({label,src});cur().bg=src}else{lib.sp.push({label,src});cur().s[upTarget].src=src}
  refresh()};r.readAsDataURL(f)};

// export / import / screenshot
$("#exp").onclick=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(P)],{type:"application/json"}));a.download=(P.title||"story").replace(/\W+/g,"_")+".json";a.click()};
$("#imp").onclick=()=>$("#impF").click();
$("#impF").onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{P=JSON.parse(r.result);sel=0;adopt();buildSlots();refresh()}catch(x){alert("Invalid file")}};r.readAsText(f)};

// ---------- play mode ----------
let playing=false,pi=0,typing=false,timer=null,autoOn=false,autoT=null;
function showLine(i){
  clearInterval(timer);clearTimeout(autoT);
  pi=i;const l=P.lines[i];renderStage(l,true);
  const full=l.text||"";let n=0;fitText(full);typing=true;$("#txt").textContent="";
  timer=setInterval(()=>{n++;$("#txt").textContent=full.slice(0,n);if(n>=full.length)doneTyping()},28);
  if(!full)doneTyping();
}
function doneTyping(){clearInterval(timer);typing=false;}
function next(){
  if(!playing)return;
  if(typing){clearInterval(timer);$("#txt").textContent=P.lines[pi].text||"";doneTyping();return}
  if(pi<P.lines.length-1)showLine(pi+1);else if($("#endcard").classList.contains("show"))stop();else $("#endcard").classList.add("show");
}
function play(from){playing=true;$("#endcard").classList.remove("show");$("#stageWrap").classList.add("playing");showLine(from);
  if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{})}
function stop(){if(!playing)return;playing=false;clearInterval(timer);clearTimeout(autoT);$("#stageWrap").classList.remove("playing");
  $("#endcard").classList.remove("show");if(document.fullscreenElement)document.exitFullscreen();sel=pi;refresh();if(SIM)$("#startScreen").style.display="grid"}
$("#playAll").onclick=()=>play(0);
$("#playHere").onclick=()=>play(sel);
$("#stage").onclick=e=>{if(e.target.id==="back")return;if(playing)next()};
$("#back").onclick=stop;
document.addEventListener("fullscreenchange",()=>{if(!document.fullscreenElement&&playing)stop()});
document.addEventListener("keydown",e=>{
  if(!playing)return;
  if(e.key==="Escape")stop();
  else if(e.key===" "||e.key==="Enter"||e.key==="ArrowRight"){e.preventDefault();next()}
  else if(e.key==="ArrowLeft"&&pi>0){$("#endcard").classList.remove("show");showLine(pi-1)}
});

adopt();buildSlots();refresh();
if(SIM){$("#stTitle").textContent=P.title;$("#startScreen").style.backgroundImage=`linear-gradient(#0009,#000d),url("${P.lines[0].bg}")`;$("#startScreen").style.display="grid";
 $("#stBtn").onclick=()=>{$("#startScreen").style.display="none";play(0)}}
// export for simulator
$("#expJs").onclick=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["window.TWST_STORY="+JSON.stringify(P)+";"],{type:"text/javascript"}));a.download="story.js";a.click()};

// ---------- localization ----------
(()=>{const L=window.TWST_LANG||{};for(const k in L){const e=document.getElementById(k);if(e&&k!=="title")e.textContent=L[k];}
 const t=document.querySelector("header h1");if(t&&L.title)t.textContent=L.title;})();

// ---------- Save PNG (renders the current line at 2560x1280) ----------
async function savePNG(){
  const W=2560,H=1280,u=W/100,c=document.createElement("canvas");c.width=W;c.height=H;const g=c.getContext("2d");
  const load=src=>new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error("load "+src));i.src=(window.TWST_DATA&&window.TWST_DATA[src])||src});
  const l=playing?P.lines[pi]:cur();
  try{await Promise.all([document.fonts.load('40px Boucherie'),document.fonts.load('40px TsukuA')]);}catch(e){}
  if(l.bg){const im=await load(l.bg),r=Math.max(W/im.width,H/im.height),w=im.width*r,h=im.height*r;g.drawImage(im,(W-w)/2,(H-h)/2,w,h);}
  for(const [k,,,base] of SLOTS){const s=l.s[k];if(!s.src)continue;
    const im=await load(s.src),h=P.size/100*H,w=h*im.width/im.height,cx=(base+(+s.x||0))/100*W,y=P.y/100*H;
    g.save();g.filter=(l.active!=="N"&&l.active!==k)?"brightness(.55)":"none";
    if(s.flip){g.translate(cx,0);g.scale(-1,1);g.drawImage(im,-w/2,y,w,h);}else g.drawImage(im,cx-w/2,y,w,h);g.restore();}
  g.drawImage(await load("public/ui/dialogue_ui.png"),0,0,W,H);
  g.textBaseline="middle";
  if(l.name){let s=2.2;g.font=`${s*u}px Boucherie, TsukuA, serif`;const mw=16*u;
    while(g.measureText(l.name).width>mw&&s>1.2){s-=.1;g.font=`${s*u}px Boucherie, TsukuA, serif`}
    g.fillStyle="#f1ede6";g.textAlign="center";g.fillText(l.name,(19.7+17.3/2)*u,(36.2+1.7)*u+u*.15);}
  let s=2.1,lines;const maxW=54*u,wrap=()=>{g.font=`${s*u}px TsukuA, sans-serif`;lines=[];
    for(const para of (l.text||"").split("\n")){let cur_="";for(const w of para.split(/(\s+)/)){const t=cur_+w;if(g.measureText(t).width>maxW&&cur_.trim()){lines.push(cur_.trimEnd());cur_=w.trimStart();}else cur_=t;}lines.push(cur_);}};
  wrap();while(lines.length*s*1.24*u>7.4*u+1&&s>1.3){s-=.08;wrap();}
  g.fillStyle="#5b5650";g.textAlign="left";lines.forEach((t,i)=>g.fillText(t,24.3*u,(40.9+ (s*1.24)/2+i*s*1.24)*u));
  c.toBlob(b=>{if(!b)return;const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=(P.title||"story").replace(/\W+/g,"_")+"_line"+((playing?pi:sel)+1)+".png";a.click();},"image/png");
}
const loadScript=src=>new Promise((res,rej)=>{const s=document.createElement("script");s.src=src;s.onload=res;s.onerror=rej;document.head.appendChild(s)});
async function savePNGSafe(){try{await savePNG();}catch(e){
  if(location.protocol==="file:"&&!window.TWST_DATA){try{await loadScript("src/assets-data.js");await savePNG();return;}catch(e2){e=e2}}
  alert("Couldn't save the PNG: "+e.message+"\n\nBrowsers block saving images when the page is opened by double-clicking the file (file://). Run start.bat (Windows) or start.sh (Mac/Linux), then open http://localhost:8080 and try again.\n(Or unzip save-png-offline-patch.zip into this folder so double-clicking works too.)");}}
const spb=document.getElementById("savePng");if(spb)spb.onclick=savePNGSafe;
document.addEventListener("keydown",e=>{if(playing&&e.key.toLowerCase()==="p")savePNGSafe();});
