/* English strings. Copy localization-template-en.json, translate it, and paste it here. */
window.TWST_LANG={
  "title": "Twisted Wonderland · Story Maker",
  "playAll": "▶ Play from start",
  "playHere": "▶ Play from here",
  "exp": "Export .json",
  "imp": "Import .json",
  "expJs": "Export for simulator",
  "savePng": "Save PNG",
  "add": "+ Add line",
  "dup": "Duplicate",
  "del": "Delete",
  "stBtn": "▶ Start Story"
};
