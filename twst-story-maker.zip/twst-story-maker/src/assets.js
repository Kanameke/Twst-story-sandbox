/* ====== ASSET MANIFEST ======
   Drop images into public/backgrounds or public/sprites, then add a line here.
   Sprites should be transparent PNGs, all the same canvas size, so they line up. */
window.TWST_ASSETS = {
  backgrounds: [
    { label: "Room (placeholder)", src: "public/backgrounds/room_placeholder.jpg" },
  ],
  sprites: [
    { label: "Neutral (eyes closed)",   src: "public/sprites/neutral_closed.png" },
    { label: "Smile",                   src: "public/sprites/smile.png" },
    { label: "Arms back (eyes closed)", src: "public/sprites/arms_back_closed.png" },
    { label: "Arms back (smile)",       src: "public/sprites/arms_back_smile.png" },
    { label: "Hands together (smile)",  src: "public/sprites/hands_together_smile.png" },
    { label: "Hands together (happy)",  src: "public/sprites/hands_together_happy.png" },
    { label: "Angry",                   src: "public/sprites/angry.png" },
    { label: "Fist (neutral)",          src: "public/sprites/fist_neutral.png" },
    { label: "Fist (smile)",            src: "public/sprites/fist_smile.png" },
    { label: "Shrug",                   src: "public/sprites/shrug.png" },
  ],
  // names that show up as suggestions in the speaker box
  characters: ["Rook (outside)", "Poomsae", "???", "Narrator"]
};
